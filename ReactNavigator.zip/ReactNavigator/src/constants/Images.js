const image1=require("../images/image1.png")

export {image1}
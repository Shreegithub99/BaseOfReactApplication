// const largelogo=require("../images/headerLogo.png")
// const smallogo=require("../images/ARLOGO2.png")
const arl = require("../../assets/favicon.png")

export default {
    
    arl

}
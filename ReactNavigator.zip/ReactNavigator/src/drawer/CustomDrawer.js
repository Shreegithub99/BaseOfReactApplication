import { View, Text } from 'react-native'
import React from 'react'

const CustomDrawer = () => {
  return (
    <View style={{flex: 1}}>
      <Text>CustomDrawer</Text>
    </View>
  )
}

export default CustomDrawer